package com.neuedu.Test;

public class Test {
    public static void main(String[] args) {
        new StudentManager().login();
    }

}
